#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

while getopts U:n:h opt; do
	case $opt in 
		U) VMM_USER_NAME="$OPTARG";;
		n) VM_HOSTNAME="$OPTARG";;
                h) HELP=1;;
	esac
done

usage() {
	echo "usage: $0 -U <vmm username> -n <vm hostname>"
	exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

ssh -l $VMM_USER_NAME vmm vmm rebuild $VM_HOSTNAME
