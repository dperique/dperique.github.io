#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
EXTRA=""
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

while getopts c:u:U:hi: opt; do
        case $opt in
                c) CUSTOMER_NAME="$OPTARG";;
                u) USER_NAME="$OPTARG";;
                U) VMM_USER_NAME="$OPTARG";;
                i) EXTRA="-i $OPTARG";;
                h) HELP=1;;
        esac
done

usage() {
cat <<EOF
usage: $0 -u <ui username> -c <ui customer name> -U <vmm username> -i <ip address for config retrieval>
EOF
exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

if [ -z "$CUSTOMER_NAME" -o -z "$USER_NAME" -o -z "$VMM_USER_NAME" ]; then
	usage
fi

TEMP_DIR=`mktemp -d`
CONFIG_TAR=${VMM_USER_NAME}.config.tgz
cd $CONFIG_BASE/$CUSTOMER_NAME/$USER_NAME > /dev/null
if [ "$?" -ne 0 ]; then
        echo "No config dir for $CUSTOMER_NAME/$USER_NAME."
        exit 1
fi
tar -czf $TEMP_DIR/$CONFIG_TAR active 2>&1 > /dev/null
if [ "$?" -ne 0 ]; then
        echo "Unable to package active config for $CUSTOMER_NAME/$USER_NAME."
        exit 1
fi
ssh -l $VMM_USER_NAME vmm vmm provision -p -s -t $TEMP_DIR/$CONFIG_TAR $EXTRA
STATUS=$?
rm -rf $TEMP_DIR
exit $STATUS
