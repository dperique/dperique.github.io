#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

ssh -l $VMM_USER_NAME vmm vmm news
