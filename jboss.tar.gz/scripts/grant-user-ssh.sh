#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

PROVISION_ARG="-a"
CLEAN_MSG=""
MESSAGE=""
EXIT_STATUS=""

while getopts u:c:U:rh opt; do
        case $opt in
                U) TARGET_USER_NAME="$OPTARG";;
                h) HELP=1;;
                r) PROVISION_ARG="-r";;
		u) USER_NAME="$OPTARG";;
		c) CUSTOMER_NAME="$OPTARG";;
        esac
done

usage() {
cat <<EOF
usage: $0 -U <vmm username> [-r] -c <ui customername> -u <ui username>
	-U: vmm username
	-u: UI username
	-c: UI customername
	-r: revoke/return username (requires -U)
EOF
exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

if [ -z "$USER_NAME" -o -z "$CUSTOMER_NAME" ]; then
	usage
fi

if [ -z "$TARGET_USER_NAME" -a "$PROVISION_ARG" == "-r" ]; then
	usage
fi	

ARGS="-c $CUSTOMER_NAME -u $USER_NAME"

if [ "$PROVISION_ARG" == "-r" ]; then
	ssh -l $VMM_USER_NAME vmm vmm provision $ARGS -v -U $TARGET_USER_NAME > /dev/null
	IN_USE=$?
	if [ "$IN_USE" == "0" ]; then
		DECOM_OUTPUT=`$SCRIPT_ROOT/decommission-ssh.sh -U $TARGET_USER_NAME`
		if [ "$DECOM_OUTPUT" == "Deactivation performed." ]; then
			CLEAN_MSG="WARNING: Attempt to release $TARGET_USER_NAME by ${CUSTOMER_NAME}:${USER_NAME} without stopping topology.  Topology automatically stopped." 
		fi
		MESSAGE=`ssh -l $VMM_USER_NAME vmm vmm provision $ARGS $PROVISION_ARG -U $TARGET_USER_NAME`
		EXIT_STATUS=$?
	else
		MESSAGE="${CUSTOMER_NAME}:${USER_NAME} does not own ${TARGET_USER_NAME}."
		EXIT_STATUS=$IN_USE
	fi
else
	MESSAGE=`ssh -l $VMM_USER_NAME vmm vmm provision $ARGS $PROVISION_ARG`
	EXIT_STATUS=$?
fi

if [ ! -z "$CLEAN_MSG" ]; then
	echo "$CLEAN_MSG"
fi
if [ ! -z "$MESSAGE" ]; then
	echo "$MESSAGE"
fi
exit $EXIT_STATUS
