#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
EXTRA=""
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi


while getopts c:u:U:hi:lom: opt; do
        case $opt in
                c) CUSTOMER_NAME="$OPTARG";;
                u) USER_NAME="$OPTARG";;
                U) VMM_USER_NAME="$OPTARG";;
		l) ACTION="load";;
		o) ACTION="open";;
		m) 
			ACTION="start"
			VM_NAME="$OPTARG"
			;;
                h) HELP=1;;
                i) EXTRA="-i $OPTARG";;
        esac
done

OUTPUT=`mktemp`

usage() {
cat <<EOF
usage: $0 -u <ui username> -c <ui customer name> -U <vmm username> [ -m vm name ]
EOF
exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

if [ -z "$CUSTOMER_NAME" -o -z "$USER_NAME" -o -z "$VMM_USER_NAME" ]; then
	usage
fi

case $ACTION in 
	"load")
		TEMP_DIR=`mktemp -d`
		CONFIG_TAR=${VMM_USER_NAME}.config.tgz
		cd $CONFIG_BASE/$CUSTOMER_NAME/$USER_NAME > /dev/null
		if [ "$?" -ne 0 ]; then
			echo "No config dir for $CUSTOMER_NAME/$USER_NAME."
			exit 1
		fi
		tar -czf $TEMP_DIR/$CONFIG_TAR active 2>&1 > /dev/null
		if [ "$?" -ne 0 ]; then
			echo "Unable to package active config for $CUSTOMER_NAME/$USER_NAME."
			exit 1
		fi
		ssh -l $VMM_USER_NAME vmm vmm provision $EXTRA -p -t $TEMP_DIR/$CONFIG_TAR > $OUTPUT
		STATUS=$?
		if [ "$STATUS" -ne "0" ]; then
			cat $OUTPUT
			exit $STATUS
		fi
		rm -rf $TEMP_DIR
		ssh -l $VMM_USER_NAME vmm vmm list | awk '{print $1}' > $OUTPUT
		;;
	"start")
		ssh -l $VMM_USER_NAME vmm vmm start $VM_NAME | grep -v bound > $OUTPUT
		STATUS=$?
		;;
	"open")
		ssh -l $VMM_USER_NAME vmm vmm sphere open | grep Cloud > $OUTPUT
		STATUS=$?
		;;
	"*")	
		usage
		;;
esac

cat $OUTPUT
rm $OUTPUT
exit $STATUS
