#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

VM_HOSTNAME=all

while getopts U:n:hl opt; do
	case $opt in 
		U) VMM_USER_NAME="$OPTARG";;
		n) VM_HOSTNAME="$OPTARG";;
		l) LIST_ONLY=1;;
                h) HELP=1;;
	esac
done

usage() {
        echo "usage: $0 -U <vmm username> [-n <vm hostname>] [-l]"
	echo "        -l: List hostnames only, do not check state"
        exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

# This is mostly to deal with vmm stat expecting the service vms to 
# have addresses which they don't.
get_host_status() {
	checkhost=$1
	ssh -l $VMM_USER_NAME vmm vmm stat --simple $checkhost 
}

get_host_status_all() {
	ssh -l $VMM_USER_NAME vmm vmm sphere stat 
}

get_host_list() {
	ssh -l $VMM_USER_NAME vmm vmm sphere custinfo \
		| grep 'VM NAME' | awk -F: '{print $2}'
}

if [ "$LIST_ONLY" == "1" ]; then
	ssh -l $VMM_USER_NAME vmm vmm list | grep -v ${VMM_USER_NAME}-nat | grep -v ${VMM_USER_NAME}-services
	exit 0
fi

case $VM_HOSTNAME in 
	all)
		get_host_status_all
	;;
	*)
		get_host_status $VM_HOSTNAME
	;;
esac
