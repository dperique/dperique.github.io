#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

while getopts U:n:h opt; do
	case $opt in 
		U) VMM_USER_NAME="$OPTARG";;
		n) VM_HOSTNAME="$OPTARG";;
                h) HELP=1;;
	esac
done

usage() {
	echo "usage: $0 -U <vmm username> [-n VM hostname]"
	exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

# Hide static/infrastructure type switches from normal users.
ssh -l $VMM_USER_NAME vmm vmm vde | egrep -v "^\"/vmm/data/vde_switches/[123]\"" | egrep -v "^\"vhost-bridge"

if [ ! -z "$VM_HOSTNAME" ]; then
	ssh -l $VMM_USER_NAME vmm vmm uuid $VM_HOSTNAME	
fi
