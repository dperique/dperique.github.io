#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

while getopts U:b:h opt; do
	case $opt in 
		U) VMM_USER_NAME="$OPTARG";;
		b) BRIDGE_NAME="$OPTARG";;
		h) HELP=1;;
	esac
done

usage() {
	echo "usage: $0 -U <vmm username> -b <bridge name>"
	exit 1
}

if [ "$HELP" == "1" ]; then
	usage
fi

ssh -l $VMM_USER_NAME vmm vmm vde -c hash/print $BRIDGE_NAME
