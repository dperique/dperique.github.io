#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

while getopts U:h opt; do
        case $opt in
                U) 
			VMM_USER_NAME="$OPTARG"
			USER_SUPPLIED=1
		;;
                h) HELP=1;;
        esac
done

usage() {
cat <<EOF
usage: $0 -U <vmm username>
EOF
exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

if [ -z "$USER_SUPPLIED" ]; then
	usage
fi

ssh -l $VMM_USER_NAME vmm vmm provision -d
STATUS=$?
exit $STATUS
