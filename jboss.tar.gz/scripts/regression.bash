#!/bin/bash

CONFIG_ROOT=/usr/local/jboss/config
SCRIPT_ROOT=/usr/local/jboss/scripts
TEST_CUSTOMER=regression
TEST_USER=testuser
CONFIG_DIR=$CONFIG_ROOT/$TEST_CUSTOMER/$TEST_USER
USERNAME=webui001
TEMPFILE1=`mktemp`
TEMPFILE2=`mktemp`
if [ -d $CONFIG_DIR ] ;then
	echo "$TEST_USER is in use, aborting."
	exit 1
fi
mkdir -p $CONFIG_DIR/active/configset
mkdir -p $CONFIG_DIR/active/scratch
# Set up default files that we'll need for the environment.
setup_topo_config_with_router_conf() {
cat > $CONFIG_DIR/active/topology.vmm <<EOF
#include "/vmm/bin/common.defs"

config "config" {

    vm "web1" {
      hostname "test-web1" ; 
      install "ENV(HOME)/active/configset/web1.conf" "/root/olive.conf" ;
      basedisk "/vmm/data/base_disks/vseries/vseries.img";
      interface "em0" { EXTERNAL; };
      interface "em1" { bridge "private0"; };
    };

    vm "web2" {
      hostname "test-web2" ; 
      install "ENV(HOME)/active/configset/web2.conf" "/root/olive.conf" ;
      basedisk "/vmm/data/base_disks/vseries/vseries.img";
      interface "em0" { EXTERNAL; };
      interface "em1" { bridge "private0"; };
      interface "em2" { bridge "private1"; };
    };

    vm "web3" {
      hostname "test-web3" ; 
      install "ENV(HOME)/active/configset/web3.conf" "/root/olive.conf" ;
      basedisk "/vmm/data/base_disks/vseries/vseries.img";
      interface "em0" { EXTERNAL; };
      interface "em1" { bridge "private1"; };
    };

PRIVATE_BRIDGES

};
EOF
cat > $CONFIG_DIR/active/configset/web1.conf <<EOF
## Last changed: 2011-02-02 13:52:03 PST
version 10.3B2.4;
groups {
    member0 {
        system {
            host-name web1;
            backup-router 10.21.0.254;
        }
    }
    global {
        system {
            time-zone America/Los_Angeles;
            debugger-on-panic;
            debugger-on-break;
            dump-on-panic;
            root-authentication {
                encrypted-password "$1$SGUyJfYE$r5hIy2IU4IamO1ye3u70v0";
            }
            name-server {
                66.129.244.5;
            }
            login {
                message "Welcome to the cloud\npassword is Clouds\n";
            }
            services {
                finger;
                ftp;
                rlogin;
                rsh;
                ssh;
                telnet;
                xnm-clear-text;
            }
            syslog {
                host log {
                    kernel info;
                    any notice;
                    pfe info;
                    interactive-commands any;
                }
                file messages {
                    kernel info;
                    any notice;
                    authorization info;
                    pfe info;
                    archive world-readable;
                }
                file security {
                    interactive-commands any;
                    archive world-readable;
                }
            }
            processes {
                routing enable;
                management enable;
                watchdog enable;
                snmp enable;
                inet-process enable;
                mib-process enable;
            }
        }
        chassis {
            dump-on-panic;
        }
        routing-options {
            static {
                route 0.0.0.0/0 next-hop 10.21.0.254;
            }
        }
    }
}
apply-groups [ global member0 ];
system {
    host-name web1;
    archival {
        configuration {
            transfer-on-commit;
            archive-sites {
                "ftp://tftp:tftp@10.21.0.254/active/configset";
            }
        }
    }
}
interfaces {
    em0 {
        unit 0 {
            family inet {
                address 10.21.0.15/24;
            }
        }
    }
}
EOF
cat > $CONFIG_DIR/active/configset/web2.conf <<EOF
## Last changed: 2011-02-02 13:53:07 PST
version 10.3B2.4;
groups {
    member0 {
        system {
            host-name web2;
            backup-router 10.21.0.254;
        }
    }
    global {
        system {
            time-zone America/Los_Angeles;
            debugger-on-panic;
            debugger-on-break;
            dump-on-panic;
            root-authentication {
                encrypted-password "$1$SGUyJfYE$r5hIy2IU4IamO1ye3u70v0";
            }
            name-server {
                66.129.244.5;
            }
            login {
                message "Welcome to the cloud\npassword is Clouds\n";
            }
            services {
                finger;
                ftp;
                rlogin;
                rsh;
                ssh;
                telnet;
                xnm-clear-text;
            }
            syslog {
                host log {
                    kernel info;
                    any notice;
                    pfe info;
                    interactive-commands any;
                }
                file messages {
                    kernel info;
                    any notice;
                    authorization info;
                    pfe info;
                    archive world-readable;
                }
                file security {
                    interactive-commands any;
                    archive world-readable;
                }
            }
            processes {
                routing enable;
                management enable;
                watchdog enable;
                snmp enable;
                inet-process enable;
                mib-process enable;
            }
        }
        chassis {
            dump-on-panic;
        }
        routing-options {
            static {
                route 0.0.0.0/0 next-hop 10.21.0.254;
            }
        }
    }
}
apply-groups [ global member0 ];
system {
    host-name web2;
    archival {
        configuration {
            transfer-on-commit;
            archive-sites {
                "ftp://tftp:tftp@10.21.0.254/active/configset";
            }
        }
    }
}
interfaces {
    em0 {
        unit 0 {
            family inet {
                address 10.21.0.19/24;
            }
        }
    }
}
EOF
cat > $CONFIG_DIR/active/configset/web3.conf <<EOF
## Last changed: 2011-02-02 13:53:49 PST
version 10.3B2.4;
groups {
    member0 {
        system {
            host-name web3;
            backup-router 10.21.0.254;
        }
    }
    global {
        system {
            time-zone America/Los_Angeles;
            debugger-on-panic;
            debugger-on-break;
            dump-on-panic;
            root-authentication {
                encrypted-password "$1$SGUyJfYE$r5hIy2IU4IamO1ye3u70v0";
            }
            name-server {
                66.129.244.5;
            }
            login {
                message "Welcome to the cloud\npassword is Clouds\n";
            }
            services {
                finger;
                ftp;
                rlogin;
                rsh;
                ssh;
                telnet;
                xnm-clear-text;
            }
            syslog {
                host log {
                    kernel info;
                    any notice;
                    pfe info;
                    interactive-commands any;
                }
                file messages {
                    kernel info;
                    any notice;
                    authorization info;
                    pfe info;
                    archive world-readable;
                }
                file security {
                    interactive-commands any;
                    archive world-readable;
                }
            }
            processes {
                routing enable;
                management enable;
                watchdog enable;
                snmp enable;
                inet-process enable;
                mib-process enable;
            }
        }
        chassis {
            dump-on-panic;
        }
        routing-options {
            static {
                route 0.0.0.0/0 next-hop 10.21.0.254;
            }
        }
    }
}
apply-groups [ global member0 ];
system {
    host-name web3;
    archival {
        configuration {
            transfer-on-commit;
            archive-sites {
                "ftp://tftp:tftp@10.21.0.254/active/configset";
            }
        }
    }
}
interfaces {
    em0 {
        unit 0 {
            family inet {
                address 10.21.0.21/24;
            }
        }
    }
}
EOF
}

# 
setup_topo_config_no_router_conf() {
cat > $CONFIG_DIR/active/topology.vmm <<EOF
#include "/vmm/bin/common.defs"

config "config" {

    vm "web1" {
      hostname "test-web1" ; 
      basedisk "/vmm/data/base_disks/vseries/vseries.img";
      interface "em0" { EXTERNAL; };
      interface "em1" { bridge "private0"; };
    };

    vm "web2" {
      hostname "test-web2" ; 
      basedisk "/vmm/data/base_disks/vseries/vseries.img";
      interface "em0" { EXTERNAL; };
      interface "em1" { bridge "private0"; };
      interface "em2" { bridge "private1"; };
    };

    vm "web3" {
      hostname "test-web3" ; 
      basedisk "/vmm/data/base_disks/vseries/vseries.img";
      interface "em0" { EXTERNAL; };
      interface "em1" { bridge "private1"; };
    };

PRIVATE_BRIDGES

};
EOF
echo "" > $CONFIG_DIR/active/configset/web1.conf 
echo "" > $CONFIG_DIR/active/configset/web2.conf 
echo "" > $CONFIG_DIR/active/configset/web3.conf 
}

# Environment setup
# Get a user id.
echo -n "Testing grant-user-ssh.sh...   "
OUTPUT=`$SCRIPT_ROOT/grant-user-ssh.sh -u $TEST_USER -c $TEST_CUSTOMER`
STATUS=$?
if [ "$STATUS" -eq "0" ]; then
	USERNAME=`echo $OUTPUT | awk '{print $2}'`
	SCR=`echo $OUTPUT | awk '{print $1}'`
	if [ "$SCR" != "Granted:" ]; then
		echo "Failed to obtain a username."
		exit 1
	else 
		echo "Successfully obtained a username: $USERNAME"
	fi
else
	echo "Failed to obtain a username."
	exit 1
fi
echo "Success."

# Testing [start|load]-ssh.sh
# This should fail.
echo -n "Testing load-ssh.sh (should fail to push non-existant topology)...   "
OUTPUT=`$SCRIPT_ROOT/load-ssh.sh -u $TEST_USER -c $TEST_CUSTOMER -U $USERNAME`
STATUS=$?
GOOD_OUTPUT=`cat <<EOF
Failed to load succesfully. Check your VMM config file.
EOF`

if [ "$OUTPUT" != "$GOOD_OUTPUT" -o "$STATUS" != "1" ]; then
	echo "load-ssh.sh reported success when it must have failed!"
	exit 1
fi
echo "Success."

# This should succeed
setup_topo_config_no_router_conf
echo -n "Testing load-ssh.sh (should push topology with no config files)...   "
OUTPUT=`$SCRIPT_ROOT/load-ssh.sh -u $TEST_USER -c $TEST_CUSTOMER -U $USERNAME`
STATUS=$?
GOOD_OUTPUT=`cat <<EOF
Load performed.
Topology started.
EOF`
if [ "$OUTPUT" != "$GOOD_OUTPUT" -o "$STATUS" != "0" ]; then
	echo "Unable to load topology!"
	exit 1
fi
echo "Success."

# Testing decommission-ssh.sh
echo -n "Testing decommission-ssh.sh (should destroy topology)...   "
OUTPUT=`$SCRIPT_ROOT/decommission-ssh.sh -U $USERNAME`
STATUS=$?
if [ "$OUTPUT" != "Deactivation performed." -o "$STATUS" != "0" ]; then
	echo "deallocation failed!"
	exit 1
fi
echo "Success."

# Testing load-ssh.sh. again.
setup_topo_config_with_router_conf
echo -n "Testing load-ssh.sh (should push topology with config files)...   "
OUTPUT=`$SCRIPT_ROOT/load-ssh.sh -u $TEST_USER -c $TEST_CUSTOMER -U $USERNAME`
STATUS=$?
GOOD_OUTPUT=`cat <<EOF
Load performed.
Topology started.
EOF`
if [ "$OUTPUT" != "$GOOD_OUTPUT" -o "$STATUS" != "0" ]; then
	echo "Unable to load topology!"
	exit 1
fi
echo "Success."

#####
##### Checking data collection
#####

#
#custinfo-ssh.sh
#
echo -n "Testing custinfo-ssh.sh....  "
$SCRIPT_ROOT/custinfo-ssh.sh -U $USERNAME > $TEMPFILE1
STATUS=$?
# Output should contain these lines
cat > $TEMPFILE2 <<EOF
##########################
   Customer: $USERNAME
   Cloud Access Portal: http://$USERNAME.cloud.juniper.net
   Root passwd: 'Clouds'
   Cloud Status : OPEN
##########################
	VM NAME: web1
	VM NAME: web2
	VM NAME: web3
==================================
	Hybridge(tm) Information:
EOF

if [ "$STATUS" != "0" ]; then
	echo "custinfo.ssh failed."
	exit 1
else
	FAILURES=0
	NUM=`wc -l $TEMPFILE1 | awk '{print $1}'`
	if [ "$NUM" != "26" ]; then
		let FAILURES++
	fi
	while read line; do
		grep "$line" $TEMPFILE1 > /dev/null || let FAILURES++
	done < $TEMPFILE2
	if [ $FAILURES -gt 0 ]; then
		echo "Failure: Unexpected output."
		exit 1
	fi
fi
rm $TEMPFILE1
rm $TEMPFILE2
echo "Success"

#
# addr-ssh.sh 
#
echo -n "Testing addr-ssh.sh...   "
# vms have to finish booting....
sleep 60
$SCRIPT_ROOT/addr-ssh.sh -U $USERNAME -b external-$USERNAME > $TEMPFILE1
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
for word in Hash Addr: VLAN; do
	num=`grep -c $word $TEMPFILE1`
	if [ $num -lt 2 ]; then
		let FAILURES++
	fi
done
rm $TEMPFILE1
if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
echo "Success."

#
# mgt-ssh.sh
#
echo -n "Testing mgt-ssh.sh...   "
$SCRIPT_ROOT/mgt-ssh.sh -U $USERNAME -b external-$USERNAME > $TEMPFILE1
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
for word in Port untagged Current Access IN OUT endpoint Strict; do
	num=`grep -c $word $TEMPFILE1`
	if [ $num -ne 4 ]; then
		let FAILURES++
	fi
done
for word in pkts bytes; do
	num=`grep -c $word $TEMPFILE1`
	if [ $num -ne 8 ]; then
		let FAILURES++
	fi
done
rm $TEMPFILE1
if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
echo "Success."

#
# news-ssh.sh
#
echo -n "Testing news-ssh.sh...   "
GOOD_OUTPUT1=`cat <<EOF
Fri Jan 28 13:24:35 PST 2011
Hello -  no news today
EOF`
TS=`date`
GOOD_OUTPUT2=`echo -e "$TS\nNo News"`
OUTPUT=`$SCRIPT_ROOT/news-ssh.sh`
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
if [  "$OUTPUT" != "$GOOD_OUTPUT1" -a "$OUTPUT" != "$GOOD_OUTPUT2" ]; then
	let FAILURES++
fi
if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	# Unexpected output is expected. It is... News.
	#exit 1
fi
echo "Success."

#
# vde-ssh.sh
#
echo -n "Testing vde-ssh.sh...   "
$SCRIPT_ROOT/vde-ssh.sh -U $USERNAME > $TEMPFILE1
cat > $TEMPFILE2 <<EOF
"external-$USERNAME":	/vmm/bin/vde_cli /vmm/data/vde_switches
"private1":	/vmm/bin/vde_cli /vmm/data/vde_switches
"private0":	/vmm/bin/vde_cli /vmm/data/vde_switches
EOF

STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
while read required; do
	grep "$required" $TEMPFILE1 > /dev/null || let FAILURES++
done < $TEMPFILE2

if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
rm $TEMPFILE1 $TEMPFILE2
echo "Success."

#
# update-ssh.sh
#
echo -n "Testing update-ssh.sh...   "
$SCRIPT_ROOT/update-ssh.sh -U $USERNAME > $TEMPFILE1
STATUS=$?
cat > $TEMPFILE2 <<EOF
web1            : VMM-Running : 
web2            : VMM-Running : 
web3            : VMM-Running : 
EOF
# All hosts
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
while read required; do
	grep "$required" $TEMPFILE1 > /dev/null || let FAILURES++
done < $TEMPFILE2
# one host
$SCRIPT_ROOT/update-ssh.sh -U $USERNAME -n web2 > $TEMPFILE1
STATUS=$?
cat > $TEMPFILE2 <<EOF
web2            : VMM-Running : 
EOF

FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
while read required; do
	grep "$required" $TEMPFILE1 > /dev/null || let FAILURES++
done < $TEMPFILE2

if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
rm $TEMPFILE1 $TEMPFILE2
echo "Success."

#
#reset-ssh.sh
#
echo -n "Testing reset-ssh.sh...   "
$SCRIPT_ROOT/reset-ssh.sh -U $USERNAME -n web2 > $TEMPFILE1
STATUS=$?
cat > $TEMPFILE2 <<EOF
Connecting to monitor port
and sending the command 'system_reset'
VM (web2) should now be reset
EOF
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
while read required; do
	grep "$required" $TEMPFILE1 > /dev/null || let FAILURES++
done < $TEMPFILE2
# This should fail (there is no web6).
$SCRIPT_ROOT/reset-ssh.sh -U $USERNAME -n web6 2>/dev/null > $TEMPFILE1
STATUS=$?
if [ $STATUS -eq 0 ]; then 
	let FAILURES++
fi
if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
rm $TEMPFILE1 $TEMPFILE2
echo "Success."

#
#rebuild-ssh.sh
#
echo -n "Testing rebuild-ssh.sh...   "
$SCRIPT_ROOT/rebuild-ssh.sh -U $USERNAME -n web2 > $TEMPFILE1
STATUS=$?
cat > $TEMPFILE2 <<EOF
Requesting vm_server
to rebuild VM web2
VM web2 was rebuilt successfully
EOF
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
while read required; do
	grep "$required" $TEMPFILE1 > /dev/null || let FAILURES++
done < $TEMPFILE2
# This should fail (there is no web6).
$SCRIPT_ROOT/rebuild-ssh.sh -U $USERNAME -n web6 2>/dev/null > $TEMPFILE1
STATUS=$?
if [ $STATUS -eq 0 ]; then 
	let FAILURES++
fi
if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
rm $TEMPFILE1 $TEMPFILE2
echo "Success."

#
#save-ssh.sh
#
echo -n "Testing save-ssh.sh...   "
ORIG_DIR=`mktemp -d`
TEST_DIR=`mktemp -d`
rsync -a /usr/local/jboss/config/$TEST_CUSTOMER/$TEST_USER/ $ORIG_DIR/
$SCRIPT_ROOT/save-ssh.sh -U $USERNAME -u $TEST_USER -c $TEST_CUSTOMER -p > $TEMPFILE1
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
$SCRIPT_ROOT/save-ssh.sh -U $USERNAME -u $TEST_USER -c $TEST_CUSTOMER > $TEMPFILE1
rsync -a /usr/local/jboss/config/$TEST_CUSTOMER/$TEST_USER/ $TEST_DIR/
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 ]; then 
	let FAILURES++
fi
OLDFILES=`cd $ORIG_DIR; find .`
NEWFILES=`cd $TEST_DIR; find .`
if [ "$OLDFILES" != "$NEWFILES" ]; then
	let FAILURES++
fi
rm -rf $ORIG_DIR $TEST_DIR $TEMPFILE1
if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
echo "Success."

#
#vde-connect-ssh.sh
#
echo -n "Testing vde-connect-ssh.sh...   "
# First, we need two switches.
SWITCHES=(`$SCRIPT_ROOT/vde-ssh.sh -U $USERNAME | grep private | awk '{print $3}'`)
SWITCH_ONE=${SWITCHES[0]}
SWITCH_TWO=${SWITCHES[1]}

# First, with no VLAN
OUTPUT=`$SCRIPT_ROOT/vde-connect-ssh.sh -C $SWITCH_ONE -S $SWITCH_TWO`
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 -o "$OUTPUT" != "Connected switches." ]; then 
	let FAILURES++
fi
# Disconnecting.
OUTPUT=`$SCRIPT_ROOT/vde-connect-ssh.sh -C $SWITCH_ONE -S $SWITCH_TWO -d`
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 -o "$OUTPUT" != "Disconnected switches." ]; then 
	let FAILURES++
fi
# Now, with a vlan
OUTPUT=`$SCRIPT_ROOT/vde-connect-ssh.sh -C $SWITCH_ONE -S $SWITCH_TWO -n 12`
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 -o "$OUTPUT" != "Connected switches." ]; then 
	let FAILURES++
fi
# Disconnecting.
OUTPUT=`$SCRIPT_ROOT/vde-connect-ssh.sh -C $SWITCH_ONE -S $SWITCH_TWO -d`
STATUS=$?
FAILURES=0
if [ $STATUS -ne 0 -o "$OUTPUT" != "Disconnected switches." ]; then 
	let FAILURES++
fi

if [ $FAILURES -gt 0 ]; then
	echo "Failure: Unexpected output."
	exit 1
fi
echo "Success."

#
# Shutting down.
#
$SCRIPT_ROOT/decommission-ssh.sh -U $USERNAME 

# Give back the user id.
OUTPUT=`$SCRIPT_ROOT/grant-user-ssh.sh -r -U $USERNAME -u $TEST_USER -c $TEST_CUSTOMER`
if [ "$STATUS" -eq "0" ]; then
	USERNAME=`echo $OUTPUT | awk '{print $2}'`
	SCR=`echo $OUTPUT | awk '{print $1}'`
	if [ "$SCR" != "Revoked:" ]; then
		echo "Failed to return a username."
		exit 1
	else 
		echo "Successfully returned a username: $USERNAME"
	fi
else
	echo "Failed to return a username."
	exit 1
fi

rm -rf $CONFIG_DIR
