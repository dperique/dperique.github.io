#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

# Predefined
REMOTE_BASE="/tftpboot"
REMOTE_USER="tftp"

while getopts c:u:U:ph opt; do
        case $opt in
                c) CUSTOMER_NAME="$OPTARG";;
                u) USER_NAME="$OPTARG";;
                U) VMM_USER_NAME="$OPTARG";;
		p) PUSH=1;;
                h) HELP=1;;
        esac
done

usage() {
cat <<EOF
usage: $0 -u <ui username> -c <ui customer name> -U <vmm username> [-p]
	-u, -c, and -U are required.  The default action is to retrieve 
	files from the service vm. If -p is supplied, the local copy is 
	pushed to the service vm.
EOF
exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

# Functions
unique_archive_configs() {
	directory=$1
	ls -1 $directory | grep gz | sed -e 's/gz_.*/gz/' | sort -u
}

supplied_configs() {
	directory=$1
	ls -1 $directory | grep -v gz | sort -u
}

most_recent() {
	directory=$1
	file=$2
	ls $directory | grep $file | sort -nr | head -1
}

config_mod_time() {
	filename=$1
	datestamp=`grep Last\ changed $filename | head -1 | sed -e 's/\#\# Last changed: //'`
	date +%s -d "$datestamp"
}

if [ -z "$CUSTOMER_NAME" -o -z "$USER_NAME" -o -z "$VMM_USER_NAME" ]; then
	usage
fi

# This will probably have to get more complicated at some point.
REMOTE_HOST=${VMM_USER_NAME}.cloud.juniper.net

export RSYNC_RSH="ssh -l $REMOTE_USER"
# Trailing slashes are significant
LOCAL_DIR="$CONFIG_BASE/$CUSTOMER_NAME/$USER_NAME/"
REMOTE_DIR="$REMOTE_HOST:$REMOTE_BASE/"
if [ "$PUSH" == "1" ]; then
	echo CMD="rsync -az $LOCAL_DIR $REMOTE_DIR"
else
	TEMP=`mktemp -d`
	TEMP_DIR="$TEMP/temp"
	TEMP_DIR_DIRTY="$TEMP/dirty"
	TEMP_DIR_CLEAN="$TEMP/clean"
	mkdir -p $TEMP_DIR $TEMP_DIR_DIRTY $TEMP_DIR_CLEAN
	CMD="rsync -az -T $TEMP_DIR $REMOTE_DIR $TEMP_DIR_DIRTY"
fi

$CMD 2>&1 > /dev/null

if [ $? -eq 1 ]; then
	echo "Sync failed."
	exit 1
fi

# Now that all files are local...
FAILURES=0
if [ ! "$PUSH" == "1" ]; then
	mkdir -p $TEMP_DIR_CLEAN/configset
	for config in `unique_archive_configs $TEMP_DIR_DIRTY/active/configset`; do
		NEWEST=`most_recent $TEMP_DIR_DIRTY/active/configset $config`
		# Incoming configs likely won't contain "_juniper" so we'll strip
		# that out from the machine generated ones.
		UNCOMPRESSED=`echo $config | sed -e 's/\.gz//' | sed -e 's/_juniper//'`
		zcat $TEMP_DIR_DIRTY/active/configset/$NEWEST > $TEMP_DIR_CLEAN//configset/$UNCOMPRESSED || let FAILURES++
		if [ -f $TEMP_DIR_DIRTY/active/configset/$UNCOMPRESSED ]; then
			NEWEST_MTIME=`config_mod_time $TEMP_DIR_DIRTY/active/configset/$NEWEST`
			EXISTING_TIME=`config_mod_time $TEMP_DIR_DIRTY/active/configset/$UNCOMPRESSED`
			if [ "$EXISTING_TIME" -gt "$NEWEST_MTIME" ]; then
				cp -f $TEMP_DIR_DIRTY/active/configset/$UNCOMPRESSED $TEMP_DIR_CLEAN/configset/$UNCOMPRESSED || let FAILURES++
			fi
		fi 
	done
	for config in `supplied_configs $TEMP_DIR_DIRTY/active/configset`; do
		if [ ! -f $TEMP_DIR_CLEAN/configset/$config ]; then
			cp -f $TEMP_DIR_DIRTY/active/configset/$config $TEMP_DIR_CLEAN/configset/$config || let FAILURES++
		fi
	done
	rsync -a $TEMP_DIR_CLEAN/ $LOCAL_DIR/active/
	rm -rf $TEMP
fi

if [ "$FAILURES" -gt "0" ]; then
	echo "Sync failed."
	exit 1
else
	echo "Sync succeeded."
fi
