#!/bin/bash

SCRIPT_ROOT=/usr/local/jboss/scripts
if [ -f $SCRIPT_ROOT/DEFAULTS ]; then
	. $SCRIPT_ROOT/DEFAULTS
fi

DISCONNECT=""

while getopts n:C:S:i:hd opt; do
        case $opt in
                C) CUST_VDE="$OPTARG";;
                S) SA_VDE="$OPTARG";;
                i) UUID="$OPTARG";;
                n) VLAN_NUMBER="$OPTARG";;
                d) DISCONNECT="-d";;
                h) HELP=1;;
        esac
done

usage() {
cat <<EOF
usage: $0 -S <SA VDE ID> -C <Customer VDE ID> -n <vlan number> -i <uuid number>
EOF
exit 1
}

if [ "$HELP" == "1" ]; then
        usage
fi

if [ -z "$CUST_VDE" -o -z "$SA_VDE" ]; then
	# VLAN number is optional.
	usage
fi

OPTIONAL=""
if [ ! -z "$VLAN_NUMBER" ]; then
	OPTIONAL="-n $VLAN_NUMBER"
fi

if [ ! -z "$UUID" ]; then
	OPTIONAL="$OPTIONAL -u $UUID"
fi

ssh -l $VMM_USER_NAME vmm vmm vde_connect -S $SA_VDE -C $CUST_VDE $OPTIONAL $DISCONNECT
